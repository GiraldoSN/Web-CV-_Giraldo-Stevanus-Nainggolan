# operasi penjumlahan dalam input
# from ast import operator
# angka1 = int(input(" Masukkan Angka =>")) 
# angka2 = int(input("Masukkan Angka =>"))
# operator = input("Masukkan Operator =>")
# if(operator == "+"):
# hasil = angka1+angka2
# print("hasil", angka1, "+", angka2, "=",hasil)

# operasi aritmatika

a = 11
b = 3

# operasi tambah +
hasil = a + b
print(a,'+',b,'=',hasil)

# operasi tambah -
hasil = a - b
print(a,'-',b,'=',hasil)

# operasi tambah /
hasil = a / b
print(a,'/',b,'=',hasil)

# operasi eksponen (pangkat) **
hasil = a ** b
print(a,'**',b,'=',hasil)

# operasi floor dividision (hasil pembulatan kebawah dari pembagian) //
hasil = a + b
print(a,'+',b,'=',hasil)

# operasi modulus (sisa pembagian) %
hasil = a // b
print(a,'//',b,'=',hasil)

#proritas operasi, operational precedence
"""
    1. ()
    2. exponen **
    3. perkalian dan teman-teman * / ** % //
    4. pertambahan dan pengurangan + -  
"""
x = 3
y = 2
z = 4

hasil = x ** y * z + x / y - y % z // x
print(x,'**',y,'*',z,'+',x,'/',y,'-',y,'%',z,'//',x,'=',hasil)

hasil = x + y * z
print(x,'+',y,'*',z,'=',hasil)
# kurung akan mengambil langakah paling pertama
hasil = (x + y) * z
print('(',x,'+',y,') *',z,'=',hasil)

# Operasi For(Looping dalam flowchart)
# for i in range (10)
# print (i)

from multiprocessing.resource_sharer import stop
from tracemalloc import start

# start = 0
# while start < 10 :
#  print(start)
#  start = start + 1
#  start += 1

print("Kalkulator ")

a = int(input("Masukkan Angka Pertama : "))
b = int(input("Masukkan Angka Kedua : "))
print("Pilih Kode Operasi : (+ , - , * , /) ")
choice = input()
if choice== "+":
    print(a+b)
elif choice == "-":
    print(a-b)
elif choice=="*":
    print(a*b)
elif choice=="/":
    print(a/b)
elif choice=="%":
    print(a%b)
else:
    print("Pilih Kode Yang Valid...!!")